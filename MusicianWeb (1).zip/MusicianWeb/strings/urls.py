from django.urls import path
from .views import RegisterView

from . import views

urlpatterns = [
    path('', views.index, name = 'index'),
    #path('login/', views.login, name = 'login'),
    #path('signUp/', views.signUp, name = 'signUp'),
    path('forum/', views.forum, name = 'forum'),
    path('profile/', views.profile, name = 'profile'),
    path('register/', RegisterView.as_view(), name = 'usersRegister'),
    path('add/', views.add, name = 'add'),
]