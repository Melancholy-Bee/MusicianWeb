from django.apps import AppConfig


class StringsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'strings'
    
    def ready(self):
        import strings.signals